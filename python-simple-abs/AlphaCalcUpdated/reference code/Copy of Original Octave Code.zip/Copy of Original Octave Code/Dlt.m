function D1=Dlt(T,Tc,Tdb)
plt=false; %plotting
D1=1e-30;
f1=func(D1,T,Tc,Tdb,false);
if f1 <0 %initial guess is either hi or low
 Dl=D1 ;
else 
 Dh=D1;
end
D2=1e-15;
f2=func(D2,T,Tc,Tdb,false);
if f2 <0 
 Dl=D2;
else 
 Dh=D2;
end
if plt
figure (2)
clf
hold on
semilogx([D1,D2],[f1,f2],'.')
endif
while D1!=D2 
D2=D1;
%abs((Dl-Dh)/(Dl+Dh))
 D1=sqrt(Dl*Dh);
 f1=func(D1,T,Tc,Tdb,false);
 if plt
  figure (2)
  plot([D1],[f1],'.')
 endif
 if f1 <0 
  Dl=D1;
 else
  Dh=D1;
 end
 
 end
if plt
 func(D1,T,Tc,Tdb,true);
end

end