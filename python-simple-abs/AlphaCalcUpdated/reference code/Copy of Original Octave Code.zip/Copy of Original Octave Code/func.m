function f=func(Delta,T,Tc,Tdb,plt)
kb=1.3806488e-23; %j/K
%Ec is the cut off energy given by debye temp
%P is 1/N0 V from above Tinkham equation 3.51
%P is ln(A*beta_c*Ec) where A=1.13, beta_c=1/(kb*Tc), Ec=hbar*wc~kb*Tdb
beta=1/(kb*T);
Ec=kb*Tdb;
P=log((1.13*Ec)/(kb*Tc));
f=f0(beta,Delta,Ec,P,plt);

end;