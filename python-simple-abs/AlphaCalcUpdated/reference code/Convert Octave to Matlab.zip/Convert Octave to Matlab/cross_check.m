function a=compute_alpha(constants,Tlist)




a=af(Tlist,constants.Tc,constants.Tdb,constants.w0);

end