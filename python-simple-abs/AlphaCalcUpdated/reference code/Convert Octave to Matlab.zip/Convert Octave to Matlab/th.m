function t=th(x)
%hyperbolic tan

t=(1-exp(-2.*x))./(1+exp(-2.*x));
end