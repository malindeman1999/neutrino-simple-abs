function s=s2approx(Tlist,Tc,Tdb,w0,Delta)
%compute approximation from jonas review (eqn (26) )

hbar=1.054571726e-34;
kb=1.3806488e-23;
%for ii=1:length(Tlist)
 %Delta(ii)=Dlt(Tlist(ii),Tc,Tdb);
%end
%Delta=1.764*kb*Tc;
s=pi.*Delta./(hbar.*w0).*(1-2.*fermi(Delta,Tlist));
end
