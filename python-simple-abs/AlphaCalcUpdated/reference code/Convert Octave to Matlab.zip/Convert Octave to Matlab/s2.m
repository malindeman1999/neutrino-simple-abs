function s=s2(Tlist,Tc,Tdb,w0,Dlist)
plt=false;
hbar=1.054571726e-34;
num=100000;
for ii=1:length(Tlist)
 Tl=Tlist(ii);
 %Delta=Dlt(Tl,Tc,Tdb);
 %Dlist(ii)=Delta;
 Delta=Dlist(ii);
 Emin=Delta-hbar*w0;
 Emax=Delta;
  if plt
  dE=(Emax-Emin)/num;
  E=Emin+dE:dE:Emax-dE;
  Int=g2(Tl,E,Delta,w0);
  estimate=trapz(E,Int)
   figure(4)
   clf
   plot(E,Int)
   xlabel('E')
   ylabel('g2')
   axis([Emin,Emax])
  end
  
 quad_options('relative tolerance',1e-15)
 [Integral,ei,xx,err]=quad(@(E) g2(Tl,E,Delta,w0),Emin,Emax,1e-15);
 s(ii)=Integral;
 

 end
end