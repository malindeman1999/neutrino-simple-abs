function f=f0(beta,Delta,Ec,P,plt)

%num=1000000;  %doesnot require huge resolution
%dE=Ec/num;

%for ii=1:num
% xi=ii*dE;
% xia(ii)=xi;
% Int=int(beta,xi,Delta);
 %In(ii)=Int;
%end
%ii=1:num;
%xia=ii.*dE;
%In=int(beta,xia,Delta);

%integral=trapz(xia,In);
[integral,err]=quadgk(@(xi) int(beta,xi,Delta),0,Ec);
f=integral-P;

if plt
 figure (1)
 loglog(xia,In)
 xlabel("E")
 ylabel('f')
 
end
end