function s=sf(Tlist,Tc,Tdb,w0,Dlist,approx)
%surface impedance
if approx
 s=s1approx(Tlist,Tc,Tdb,w0,Dlist)-i*s2approx(Tlist,Tc,Tdb,w0,Dlist);
else
 s=s1(Tlist,Tc,Tdb,w0,Dlist)-i*s2(Tlist,Tc,Tdb,w0,Dlist);
end


end