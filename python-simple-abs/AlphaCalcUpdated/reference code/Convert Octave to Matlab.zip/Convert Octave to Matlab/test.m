
figure (1)
clf
T0=.5;
dT=.03
Tc=14;
Tdb=275.;
for ii=1:20
T=T0+dT*ii;
Tlist(ii)=T;
Dlist(ii)=Dlt(T,Tc,Tdb);
end

plot(Tlist,Dlist,"^")
dD=max(Dlist)-min(Dlist)
frac=dD/min(Dlist)
axis([min(Tlist) max(Tlist) min(Dlist) max(Dlist)]);
