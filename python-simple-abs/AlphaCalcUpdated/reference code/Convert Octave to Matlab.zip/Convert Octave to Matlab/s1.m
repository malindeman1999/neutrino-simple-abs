function s=s1(Tlist,Tc,Tdb,w0,Dlist)
%Here is sigma_1:  This function computes sigma_1 for a list of temperatures in Tlist
plt=false;

for ii=1:length(Tlist)
num=100000;
 Tl=Tlist(ii);
 %Delta=Dlt(Tl,Tc,Tdb);
 %Dlist(ii)=Delta;
 Delta=Dlist(ii);
 Emin=Delta;
 Emax=Delta*1.5;
 
 %dE=(Emax-Emin)/num;
 %E=Emin+dE:dE:Emax; %singulatriy at Emin
 %Int=g(E,Tl,Delta,w0);
 %s(ii)=trapz(E,Int);
 
 [Integral,err]=quadcc(@(E) g(E,Tl,Delta,w0),Emin,Emax);
 s(ii)=Integral;
 if plt
 figure(3)
 clf
 plot(E,Int)
 xlabel('E')
 ylabel('g1')
 axis([Emin,Emax])
 end
end