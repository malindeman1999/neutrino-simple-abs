function Z=Zf(Tlist,Tc,Tdb,w0,approx);
% returns 3 columns of data correponding to Z
% in Z=[transpose(ZThickLocal),transpose(ZExtremeAnom),transpose(ZThin)

%mu0=4*pi*1e-7;
%hbar=1.054571726e-34;

for ii=1:length(Tlist)
 Tl=Tlist(ii);
 Dlist(ii)=Dlt(Tl,Tc,Tdb);
end

sigma=sf(Tlist,Tc,Tdb,w0,Dlist,approx);
%set the constants sigma(T=0),Z(T=0) to unit magnitude because they divide out of alpha anyway
Z0=i;  %these must have correct phases to work out in roots correctly
sigma0=-i;  %the magnitudes do not affect alpha

%from Jonas (9)  the therm in the brackets is really just sigma(T)/sigma(0)
%the numerator is just Z(T=0)
term=sigma./sigma0;  %positive at T=0
ZThickLocal=Z0./sqrt(term);
ZThickLocal=sqrt(i.*mu.*w0/sigma);

%from Jonas eqn (9) 
ZExtremeAnom=Z0.*(term).^(-1/3);  
%from Jonas eqn 11
ZThin=Z0./(term);
Z=[transpose(ZThickLocal),transpose(ZExtremeAnom),transpose(ZThin)
];



end