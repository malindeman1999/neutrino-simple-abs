function g=g2(T,E,Delta,w)
%The integrand to find sigma2 from Mazin thesis eqn 2.4
hbar=1.054571726e-34;
x=1./(hbar.*w).*(E.^2+Delta.^2+hbar.*w.*E)./(sqrt(Delta.^2-E.^2).*sqrt((E+hbar.*w).^2-Delta.^2)).*(1-2.*fermi(E,T));
g=real(x);
end
