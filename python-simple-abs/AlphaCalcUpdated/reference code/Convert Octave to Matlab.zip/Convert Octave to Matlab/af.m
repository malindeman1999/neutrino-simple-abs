function a=af(Tlist,Tc,Tdb,w0,approx)
%computes alpha
ef=0.1;
%three colums correspond to 
%Z=[transpose(ZThickLocal),transpose(ZExtremeAnom),transpose(ZThin)

Z1=Zf(Tlist,Tc,Tdb,w0,approx);
Z2=Zf(Tlist.*(1.+ef),Tc,Tdb,w0,approx);
Rlist=real(Z1+Z2)./2;
Tl=transpose(Tlist);
Tmatrix=[Tl,Tl,Tl];

a=(Tmatrix./Rlist.*(Z2-Z1)./(ef.*Tmatrix));


end