function s=s1approx(Tlist,Tc,Tdb,w0,Delta)
%The approximate answer from Jonas review eq 16 is
hbar=1.054571726e-34;
kb=1.3806488e-23;
%for ii=1:length(Tlist)
% Delta(ii)=Dlt(Tlist(ii),Tc,Tdb);
%end
Delta0=1.764*kb*Tc;
s=4.*Delta./(hbar.*w0).*exp(-Delta0./(kb.*Tlist)).*sinh(hbar.*w0./(2.*kb.*Tlist)).*besselk(0,hbar.*w0./(2.*kb.*Tlist));
end