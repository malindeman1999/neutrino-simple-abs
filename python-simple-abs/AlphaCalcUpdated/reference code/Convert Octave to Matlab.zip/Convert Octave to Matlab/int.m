function inte=int(beta,xi,Delta)

inte= th(1./2.*beta.*sqrt(xi.^2+Delta.^2))./sqrt(xi.^2+Delta.^2);

end