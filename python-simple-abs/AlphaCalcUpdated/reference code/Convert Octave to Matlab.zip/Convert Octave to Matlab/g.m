function gv=g(E,T,Delta,w)
hbar=1.054571726e-34;
%The integrand to find sigma1 from Jonas review eqn 1
g1=2./(hbar.*w).*(E.^2+Delta.^2+hbar.*w.*E)./(sqrt(E.^2-Delta.^2).*sqrt((E+hbar.*w).^2-Delta.^2)).*(fermi(E,T)-fermi(E+hbar*w,T));
gv=real(g1);
end