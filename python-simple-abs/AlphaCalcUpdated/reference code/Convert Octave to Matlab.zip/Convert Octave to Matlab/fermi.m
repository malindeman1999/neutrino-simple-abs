function f=fermi(E,T)
kb=1.3806488e-23;
f=1./(exp(E./(kb.*T))+1);
end