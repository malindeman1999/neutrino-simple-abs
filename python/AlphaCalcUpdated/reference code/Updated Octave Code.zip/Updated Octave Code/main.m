figure(1)
clf
hold on

x.Tc=1;
x.Tdb=275;
x.w0=1.194e9*2*pi;
x.type='lowT';
constants_lowT=x;


x.Tc=14;
x.Tdb=275;
x.w0=1.194e9*2*pi;
x.type='TEST';
constants_TEST=x;


 x.Tc=14;
 x.Tdb=275;
 x.w0=1.194e9*2*pi;
 x.type="NbTiN";
constants_NBTiN=x;



TArray=[];
AlphaArray=[];
constants=constants_lowT
file=strcat(constants.type,".sav");

if exist(file,'file')  %load any points already calculated
 load(file)
  file
end
temps=[];
AlphaSet=[];

%% SET the temps to calculate here
%temps= [.61:.002:.63];  %set to null to plot old data
%temps=[1:10]
%;temps=.75+[1:9];
temps=[.2,.4,.6,.8]


approx=false
if length(temps)>0
 AlphaSet=compute_alpha(constants,temps,approx);
 %AlphaSet columns correspond to [transpose(ZThickLocal),transpose(ZExtremeAnom),transpose(ZThin)
end
sz=size(AlphaArray)
TArray=[TArray,temps];
AlphaArray=[AlphaArray;AlphaSet];


save(file,'TArray','AlphaArray')  ; %save data

hf=figure(100)
clf
hold on
[dum,s]=sort(TArray);
%three columns of data correspond to
%Z=[transpose(ZThickLocal),transpose(ZExtremeAnom),transpose(ZThin)

Label={"0;thick local;","1;ext. anom.;", "2;thin;"};
Label2=["0","1","2"];
color=0;
hlist1=[];
hlist2=[];
jj=0;
for kk=1:3
 ii=mod(kk+1+1,3)+1  ; %rotate plot order
 alpha=AlphaArray(:,ii);
 h=semilogy(TArray(s),real(alpha(s)));
 hlist1(++jj)=h;
 set(h,'linewidth', 1)
 h1=semilogy(TArray(s),imag(alpha(s))) ;
 hlist2(jj)=h1;

 set(h1,'linewidth',1)
 h=get(hf,'children');



end
% Add labels, title, and legend to distinguish between the two curves

  title('Alpha vs. Temperature');
  legend('thick Local (real)', 'thick local (imag)', 'ext anom (real)', 'ext anom (imag)' , 'thin (real)', 'thin (imag)')
%Rainbow(hlist1);
%Rainbow(hlist2);
xlabel("temperature (K)")
ylabel("alpha")
legend('location','east')

save(file,'TArray','AlphaArray')  ; %save data
