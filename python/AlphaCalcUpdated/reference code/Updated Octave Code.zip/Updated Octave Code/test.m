format long

figure (1)
clf
T0=.5;
dT=5
Tc=14;
Tdb=275.;


 x.Tc=14;
 x.Tdb=275;
 x.w0=1.194e9*2*pi;
 x.type="NbTiN";
constants_NBTiN=x;


freq= 1e9 % Hz
w0=2*pi*freq

for ii=1:2
  T=T0+dT*ii;
  Tlist(ii)=T;
  display(T)
  Dlist(ii)=Dlt(T,Tc,Tdb); %verified
end

approx = false

%data_list = Dlist;  #conversion to python verified
%data_list = s1(Tlist, Tc, Tdb, w0, Dlist);#conversion to python verified
%data_list = s2(Tlist, Tc, Tdb, w0, Dlist);  #conversion to python verified
%data_list = sf(Tlist,Tc,Tdb,w0,Dlist,approx );  #conversion to python verified
%data_list = Zf(Tlist, Tc, Tdb, w0, approx); #conversion to python verified
%data_list =af(Tlist, Tc, Tdb, w0, approx); #conversion to python verified
data_list= compute_alpha(constants_NBTiN, Tlist, approx)

display(data_list)
plot(Tlist,data_list,"^")

axis([min(Tlist) max(Tlist) min(data_list) max(data_list)]);

