format long

T = 1.4000000000000001;
Delta = 3.401720202972295e-22;
Tc = 14;
w0 = 7502123256.772426;

Tdb = 0


result1 = s1approx(T,Tc,Tdb,w0,Delta)
result2 = s2approx(T,Tc,Tdb,w0,Delta)




disp(result1);
disp(result2);

