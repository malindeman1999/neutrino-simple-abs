function a=compute_alpha(constants,Tlist,approx)


%three columns of data correspond to
%Z=[transpose(ZThickLocal),transpose(ZExtremeAnom),transpose(ZThin)

a=af(Tlist,constants.Tc,constants.Tdb,constants.w0,approx);

end
