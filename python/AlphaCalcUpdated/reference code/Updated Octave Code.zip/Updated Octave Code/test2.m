% Create the x values for the range of interest
x = linspace(0, 2 * pi, 1000);

% Define the first curve as sine and the second as cosine
y1 = sin(x);
y2 = cos(x);

% Create the figure
figure;

% Plot the first curve in blue and label it
plot(x, y1, 'b', 'LineWidth', 2);
hold on;

% Plot the second curve in red and label it
plot(x, y2, 'r', 'LineWidth', 2);

% Add labels, title, and legend to distinguish between the two curves
xlabel('x values');
ylabel('y values');
title('Plot of sin(x) and cos(x)');
legend('sin(x)', 'cos(x)');

% Grid for better visualization
grid on;

% Hold off to end plotting
hold off;
